#!/usr/bin/env python3
"""
Interface LMA - Couleurs du Maroc 🇲🇦
Simplifiée et élégante

Couleurs:
- Rouge Maroc: #C1272D
- Vert Maroc: #006233
- Or: #FFD700
"""

import tkinter as tk
from tkinter import ttk, messagebox
import subprocess
import sys
from biblio_improved import BibliothequeArticles
from pathlib import Path

class BibliothequeGUI:
    def __init__(self):
        self.biblio = BibliothequeArticles()
        
        # Nettoyage automatique au démarrage
        self.nettoyer_au_demarrage()
        
        self.root = tk.Tk()
        self.root.title("LMA")
        self.root.geometry("1400x900")
        
        # ===== COULEURS DU MAROC =====
        self.rouge_maroc = "#C1272D"      # Rouge drapeau
        self.vert_maroc = "#006233"       # Vert étoile
        self.or_maroc = "#FFD700"         # Or
        self.beige = "#F5E6D3"            # Beige clair
        self.beige_fonce = "#E8D5B7"      # Beige foncé
        self.texte_fonce = "#2C1810"      # Marron foncé
        self.blanc = "#FFFFFF"
        
        self.root.configure(bg=self.beige)
        self.mode_affichage = "tous"
        
        self.create_widgets()
    
    def nettoyer_au_demarrage(self):
        """Nettoie automatiquement la base de données au démarrage"""
        try:
            supprimes = self.biblio.nettoyer_articles_manquants()
            if supprimes > 0:
                print(f"🧹 Nettoyage: {supprimes} entrée(s) supprimée(s)")
        except Exception as e:
            print(f"Erreur nettoyage: {e}")
    
    def create_widgets(self):
        """Créer l'interface"""
        
        # ===== HEADER =====
        header = tk.Frame(self.root, bg=self.rouge_maroc, height=50)
        header.pack(fill='x')
        header.pack_propagate(False)
        
        tk.Label(header,
                text=" LMA",
                font=("SF Pro Display", 20, "bold"),
                bg=self.rouge_maroc,
                fg=self.blanc).pack(pady=12)
        
        # ===== RECHERCHE =====
        search_container = tk.Frame(self.root, bg=self.beige)
        search_container.pack(fill='x', padx=15, pady=(10, 5))
        
        search_frame = tk.Frame(search_container, bg=self.beige)
        search_frame.pack(expand=True)
        
        tk.Label(search_frame,
                text="🔍",
                font=("SF Pro Display", 14),
                bg=self.beige,
                fg=self.vert_maroc).pack(side='left', padx=(0, 8))
        
        self.search_entry = tk.Entry(search_frame,
                                     font=("SF Pro Display", 13),
                                     bg=self.blanc,
                                     fg=self.texte_fonce,
                                     insertbackground=self.rouge_maroc,
                                     relief='flat',
                                     width=50,
                                     bd=1,
                                     highlightthickness=1,
                                     highlightbackground=self.beige_fonce,
                                     highlightcolor=self.rouge_maroc)
        self.search_entry.pack(side='left', ipady=5, ipadx=12)
        self.search_entry.bind('<KeyRelease>', lambda e: self.rechercher_articles())
        
        # ===== FILTRES =====
        filter_frame = tk.Frame(self.root, bg=self.beige)
        filter_frame.pack(fill='x', padx=15, pady=(5, 8))
        
        # Bouton TOUS
        self.btn_tous = tk.Label(filter_frame,
                                text="📚 ALL",
                                font=("SF Pro Display", 11, "bold"),
                                bg=self.vert_maroc if self.mode_affichage == "tous" else self.beige_fonce,
                                fg=self.blanc if self.mode_affichage == "tous" else self.texte_fonce,
                                cursor="hand2",
                                padx=15,
                                pady=6,
                                relief='flat')
        self.btn_tous.pack(side='left', padx=3)
        self.btn_tous.bind('<Button-1>', lambda e: self.afficher_tous())
        
        # Bouton À LIRE
        self.btn_a_lire = tk.Label(filter_frame,
                                   text="📖 TO READ",
                                   font=("SF Pro Display", 11, "bold"),
                                   bg=self.rouge_maroc if self.mode_affichage == "a_lire" else self.beige_fonce,
                                   fg=self.blanc if self.mode_affichage == "a_lire" else self.texte_fonce,
                                   cursor="hand2",
                                   padx=15,
                                   pady=6,
                                   relief='flat')
        self.btn_a_lire.pack(side='left', padx=3)
        self.btn_a_lire.bind('<Button-1>', lambda e: self.afficher_a_lire())
        
        # ===== BOUTONS D'ACTION =====
        button_frame = tk.Frame(self.root, bg=self.beige)
        button_frame.pack(fill='x', padx=15, pady=(3, 8))
        
        button_container = tk.Frame(button_frame, bg=self.beige)
        button_container.pack(expand=True)
        
        # Refresh
        self.creer_bouton(button_container, "🔄", self.refresh_articles, self.vert_maroc)
        
        # Index
        self.creer_bouton(button_container, "📥", self.indexer_pdfs, self.rouge_maroc)
        
        # Clean
        self.creer_bouton(button_container, "🧹", self.nettoyer_manuellement, self.or_maroc)
        
        # ===== TREEVIEW =====
        tree_container = tk.Frame(self.root, bg=self.beige)
        tree_container.pack(fill='both', expand=True, padx=20, pady=10)
        
        # Scrollbar
        scrollbar = ttk.Scrollbar(tree_container)
        scrollbar.pack(side='right', fill='y')
        
        # Style
        style = ttk.Style()
        style.theme_use('clam')
        
        style.configure("Treeview",
                       background=self.blanc,
                       foreground=self.texte_fonce,
                       fieldbackground=self.blanc,
                       borderwidth=0,
                       font=("SF Pro Display", 13),
                       rowheight=45)
        
        style.configure("Treeview.Heading",
                       background=self.beige_fonce,
                       foreground=self.rouge_maroc,
                       borderwidth=0,
                       font=("SF Pro Display", 13, "bold"))
        
        style.map('Treeview',
                 background=[('selected', self.vert_maroc)])
        
        # TreeView
        self.tree = ttk.Treeview(tree_container,
                                columns=('Title', 'Author', 'Year'),
                                show='headings',
                                yscrollcommand=scrollbar.set,
                                selectmode='browse',
                                style="Treeview")
        
        self.tree.heading('Title', text='📖 TITLE')
        self.tree.heading('Author', text='👤 AUTHOR')
        self.tree.heading('Year', text='📅 YEAR')
        
        self.tree.column('Title', width=700, anchor='w')
        self.tree.column('Author', width=350, anchor='w')
        self.tree.column('Year', width=100, anchor='center')
        
        self.tree.pack(side='left', fill='both', expand=True)
        scrollbar.config(command=self.tree.yview)
        
        # Tags
        self.tree.tag_configure("a_lire", 
                               background="#FFE6E6",
                               foreground=self.rouge_maroc)
        self.tree.tag_configure("normal", 
                               background=self.blanc,
                               foreground=self.texte_fonce)
        
        # Double-clic
        self.tree.bind('<Double-1>', self.on_double_click)
        
        # Menu contextuel
        self.context_menu = tk.Menu(self.root, tearoff=0,
                                    bg=self.beige_fonce,
                                    fg=self.texte_fonce,
                                    activebackground=self.vert_maroc,
                                    activeforeground=self.blanc)
        self.context_menu.add_command(label="📖 Open PDF", command=self.open_selected_pro)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="📌 Mark TO READ", command=lambda: self.toggle_a_lire(True))
        self.context_menu.add_command(label="✅ Mark DONE", command=lambda: self.toggle_a_lire(False))
        
        self.tree.bind('<Button-2>', self.show_context_menu)
        self.tree.bind('<Button-3>', self.show_context_menu)
        
        # ===== BARRE D'ACTION PRINCIPALE =====
        action_frame = tk.Frame(self.root, bg=self.beige)
        action_frame.pack(fill='x', padx=15, pady=(5, 8))
        
        action_container = tk.Frame(action_frame, bg=self.beige)
        action_container.pack(expand=True)
        
        # Ouvrir
        self.creer_bouton_action(action_container, "📄 Open", 
                                 self.open_selected_pro, self.vert_maroc)
        
        # Marquer à lire
        self.creer_bouton_action(action_container, "📌 TO READ",
                                 lambda: self.toggle_a_lire(True), self.rouge_maroc)
        
        # Marquer comme lu
        self.creer_bouton_action(action_container, "✅ DONE",
                                 lambda: self.toggle_a_lire(False), self.or_maroc)
        
        # ===== STATUS BAR =====
        status_frame = tk.Frame(self.root, bg=self.beige_fonce, height=26)
        status_frame.pack(fill='x', side='bottom')
        status_frame.pack_propagate(False)
        
        self.status_label = tk.Label(status_frame,
                                     text="Ready 🇲🇦",
                                     font=("SF Pro Display", 10),
                                     bg=self.beige_fonce,
                                     fg=self.texte_fonce,
                                     anchor='w')
        self.status_label.pack(side='left', padx=15, pady=4)
        
        # Charger articles
        self.refresh_articles()
    
    def creer_bouton(self, parent, texte, commande, couleur):
        """Créer un bouton de toolbar"""
        btn = tk.Label(parent,
                      text=texte,
                      font=("SF Pro Display", 13),
                      bg=couleur,
                      fg=self.blanc,
                      cursor="hand2",
                      padx=12,
                      pady=4,
                      relief='flat')
        btn.pack(side='left', padx=2)
        btn.bind('<Button-1>', lambda e: commande())
        
        # Hover effect
        def on_enter(e):
            btn.config(relief='raised')
        def on_leave(e):
            btn.config(relief='flat')
        
        btn.bind('<Enter>', on_enter)
        btn.bind('<Leave>', on_leave)
        
        return btn
    
    def creer_bouton_action(self, parent, texte, commande, couleur):
        """Créer un bouton d'action principal"""
        btn = tk.Label(parent,
                      text=texte,
                      font=("SF Pro Display", 12, "bold"),
                      bg=couleur,
                      fg=self.blanc,
                      cursor="hand2",
                      padx=20,
                      pady=8,
                      relief='flat')
        btn.pack(side='left', padx=5)
        btn.bind('<Button-1>', lambda e: commande())
        
        # Hover effect
        def on_enter(e):
            btn.config(relief='raised')
        def on_leave(e):
            btn.config(relief='flat')
        
        btn.bind('<Enter>', on_enter)
        btn.bind('<Leave>', on_leave)
        
        return btn
    
    def afficher_tous(self):
        """Afficher tous les articles"""
        self.mode_affichage = "tous"
        
        self.btn_tous.configure(bg=self.vert_maroc, fg=self.blanc)
        self.btn_a_lire.configure(bg=self.beige_fonce, fg=self.texte_fonce)
        
        self.refresh_articles()
    
    def afficher_a_lire(self):
        """Afficher seulement les articles à lire"""
        self.mode_affichage = "a_lire"
        
        self.btn_tous.configure(bg=self.beige_fonce, fg=self.texte_fonce)
        self.btn_a_lire.configure(bg=self.rouge_maroc, fg=self.blanc)
        
        self.refresh_articles()
    
    def refresh_articles(self):
        """Rafraîchir la liste"""
        self.biblio.invalider_cache()
        self.biblio._build_file_cache()
        
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        if self.mode_affichage == "a_lire":
            articles = self.biblio.lister_a_lire()
        else:
            articles = self.biblio.lister_articles()
        
        for article in articles:
            tags = (article['fichier'], "a_lire" if article.get('a_lire', False) else "normal")
            self.tree.insert('', 'end',
                           values=(article['titre'], article['auteurs'], article['annee']),
                           tags=tags)
        
        self.update_status()
    
    def rechercher_articles(self):
        """Rechercher des articles"""
        requete = self.search_entry.get()
        
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        if not requete:
            self.refresh_articles()
            return
        
        resultats = self.biblio.rechercher(requete)
        
        for article in resultats:
            tags = (article['fichier'], "a_lire" if article.get('a_lire', False) else "normal")
            self.tree.insert('', 'end',
                           values=(article['titre'], article['auteurs'], article['annee']),
                           tags=tags)
        
        self.update_status(f"🔍 {len(resultats)} résultat(s)")
    
    def update_status(self, message=None):
        """Mettre à jour la barre de statut"""
        if message:
            self.status_label.config(text=message)
        else:
            total = self.biblio.compter_articles()
            a_lire = len(self.biblio.lister_a_lire())
            self.status_label.config(text=f"📚 {total} articles | 📖 {a_lire} to read")
    
    def show_context_menu(self, event):
        """Afficher le menu contextuel"""
        item = self.tree.identify_row(event.y)
        if item:
            self.tree.selection_set(item)
            self.context_menu.post(event.x_root, event.y_root)
    
    def toggle_a_lire(self, a_lire: bool):
        """Marquer/démarquer comme à lire"""
        selection = self.tree.selection()
        if not selection:
            messagebox.showwarning("Attention", 
                                  "Veuillez sélectionner un article",
                                  parent=self.root)
            return
        
        for item in selection:
            item_data = self.tree.item(item)
            nom_fichier = item_data["tags"][0]
            self.biblio.marquer_a_lire(nom_fichier, a_lire)
        
        action = "ajouté à" if a_lire else "retiré de"
        messagebox.showinfo("✓", 
                           f"Article {action} la liste 'À lire' !",
                           parent=self.root)
        self.refresh_articles()
    
    def on_double_click(self, event):
        """Ouvrir au double-clic"""
        self.open_selected_pro()
    
    def get_pdf_path(self, nom_fichier):
        """Obtenir le chemin du PDF"""
        return self.biblio.get_chemin_fichier(nom_fichier)
    
    def open_selected_pro(self):
        """Ouvrir avec le lecteur moderne"""
        selection = self.tree.selection()
        if not selection:
            messagebox.showwarning("Attention", 
                                  "Veuillez sélectionner un article",
                                  parent=self.root)
            return
        
        item = self.tree.item(selection[0])
        nom_fichier = item["tags"][0]
        
        chemin_pdf = self.get_pdf_path(nom_fichier)
        
        if chemin_pdf and chemin_pdf.exists():
            try:
                from lecteurpdf_fast import ouvrir_pdf_rapide as ouvrir_pdf_moderne
                ouvrir_pdf_moderne(str(chemin_pdf), self.root)
                self.update_status(f"📖 Ouvert: {nom_fichier}")
                
            except ImportError:
                messagebox.showerror("Erreur", 
                                   "❌ lecteur_pdf_moderne.py introuvable!\n\n"
                                   "Dépendances:\n"
                                   "pip3 install PyMuPDF pillow",
                                   parent=self.root)
            except Exception as e:
                messagebox.showerror("Erreur", 
                                   f"Impossible d'ouvrir:\n{e}",
                                   parent=self.root)
        else:
            messagebox.showerror("Erreur", 
                               f"Fichier introuvable: {nom_fichier}",
                               parent=self.root)
    
    def indexer_pdfs(self):
        """Indexer les nouveaux PDFs"""
        self.biblio.indexer_dossier()
        messagebox.showinfo("✓", "Indexation terminée!",
                           parent=self.root)
        self.refresh_articles()
    
    def nettoyer_manuellement(self):
        """Nettoyer la base de données"""
        reponse = messagebox.askyesno("Confirmer",
                                      "Supprimer les entrées des PDFs manquants?",
                                      parent=self.root)
        
        if reponse:
            supprimes = self.biblio.nettoyer_articles_manquants()
            messagebox.showinfo("✓",
                              f"🧹 {supprimes} entrée(s) supprimée(s)!",
                              parent=self.root)
            self.refresh_articles()

def main():
    app = BibliothequeGUI()
    app.root.mainloop()

if __name__ == "__main__":
    main()