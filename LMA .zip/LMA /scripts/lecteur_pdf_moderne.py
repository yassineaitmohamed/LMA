#!/usr/bin/env python3
"""
🚀 LECTEUR PDF OPTIMISÉ - macOS Monterey 12.7.6
MacBook Pro 13" 2016

Fonctionnalités adaptées:
- ⚡ Performance optimisée pour Intel Core i7
- 🖱️ Scroll fluide avec trackpad
- 🖍️ Stylo pour surligner
- 🎨 Choix de couleurs
- 🔍 Recherche rapide
- 🌓 Thème clair/sombre
- 💾 Sauvegarde automatique
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog, colorchooser
import fitz  # PyMuPDF
from pathlib import Path
from PIL import Image, ImageTk, ImageDraw
import threading
from collections import OrderedDict
import json
from datetime import datetime
import platform

# ============================================================================
# DÉTECTION SYSTÈME
# ============================================================================

IS_MAC = platform.system() == 'Darwin'
MONTEREY_VERSION = '12.7.6'

# ============================================================================
# CACHE INTELLIGENT LRU
# ============================================================================

class CacheLRU:
    """Cache LRU optimisé"""
    def __init__(self, taille_max=15):  # Réduit pour votre système
        self.cache = OrderedDict()
        self.taille_max = taille_max
    
    def get(self, cle):
        if cle in self.cache:
            self.cache.move_to_end(cle)
            return self.cache[cle]
        return None
    
    def set(self, cle, valeur):
        if cle in self.cache:
            self.cache.move_to_end(cle)
        self.cache[cle] = valeur
        if len(self.cache) > self.taille_max:
            self.cache.popitem(last=False)
    
    def clear(self):
        self.cache.clear()

# ============================================================================
# GESTIONNAIRE D'ANNOTATIONS
# ============================================================================

class GestionnaireAnnotations:
    """Gestion des surlignages"""
    
    def __init__(self, fichier_pdf):
        self.fichier_pdf = Path(fichier_pdf)
        self.fichier_annot = self.fichier_pdf.with_suffix('.annotations.json')
        self.annotations = self.charger()
    
    def charger(self):
        if self.fichier_annot.exists():
            try:
                with open(self.fichier_annot, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        return {'highlights': {}}
    
    def sauvegarder(self):
        try:
            with open(self.fichier_annot, 'w', encoding='utf-8') as f:
                json.dump(self.annotations, f, indent=2)
            return True
        except Exception as e:
            print(f"Erreur sauvegarde: {e}")
            return False
    
    def ajouter_highlight(self, page, coords, couleur):
        page_key = str(page)
        if page_key not in self.annotations['highlights']:
            self.annotations['highlights'][page_key] = []
        
        self.annotations['highlights'][page_key].append({
            'coords': coords,
            'couleur': couleur,
            'date': datetime.now().isoformat()
        })
        self.sauvegarder()
    
    def get_highlights(self, page):
        page_key = str(page)
        return self.annotations['highlights'].get(page_key, [])
    
    def effacer_highlights(self, page):
        page_key = str(page)
        if page_key in self.annotations['highlights']:
            self.annotations['highlights'][page_key] = []
            self.sauvegarder()

# ============================================================================
# LECTEUR PDF OPTIMISÉ POUR VOTRE MAC
# ============================================================================

class LecteurPDFModerne:
    def __init__(self, fichier_pdf, parent=None):
        self.fichier_pdf = Path(fichier_pdf)
        self.parent = parent
        
        # État
        self.doc = None
        self.page_actuelle = 0
        self.zoom = 1.2  # Optimisé pour 13"
        self.mode_sombre = False
        
        # Cache optimisé pour Intel i7
        self.cache_pages = CacheLRU(taille_max=15)
        self.cache_miniatures = {}
        
        # Recherche
        self.resultats_recherche = []
        self.index_recherche = 0
        
        # Annotations
        self.gestionnaire_annot = None
        self.mode_stylo = False
        self.couleur_stylo = '#FFFF00'
        self.drawing = False
        self.draw_start = None
        self.rectangles_temp = []
        
        # Performance
        self.preload_active = True
        
        # Créer fenêtre
        self.root = tk.Toplevel() if parent else tk.Tk()
        self.root.title(f"📄 {self.fichier_pdf.name}")
        self.root.geometry("1280x800")  # Optimisé pour 13"
        
        # Thème
        self.init_theme()
        
        # Charger PDF
        try:
            self.doc = fitz.open(str(self.fichier_pdf))
            self.total_pages = len(self.doc)
            self.gestionnaire_annot = GestionnaireAnnotations(fichier_pdf)
        except Exception as e:
            messagebox.showerror("Erreur", f"Impossible d'ouvrir le PDF:\n{e}")
            self.root.destroy()
            return
        
        # Interface
        self.creer_interface()
        
        # Afficher première page
        self.afficher_page()
        
        # Démarrer préchargement
        self.demarrer_preload()
        
        # Raccourcis
        self.bind_raccourcis()
        
        # Événements scroll optimisés pour macOS
        self.bind_scroll_macos()
    
    def init_theme(self):
        """Thèmes macOS"""
        self.theme_clair = {
            'bg': '#f5f5f5',
            'bg_sidebar': '#ebebeb',
            'bg_toolbar': '#e8e8e8',
            'bg_canvas': '#ffffff',
            'fg': '#1d1d1f',
            'fg_secondary': '#6e6e73',
            'accent': '#007aff',
            'hover': '#0051d5',
            'border': '#d1d1d6'
        }
        
        self.theme_sombre = {
            'bg': '#1c1c1e',
            'bg_sidebar': '#2c2c2e',
            'bg_toolbar': '#1c1c1e',
            'bg_canvas': '#2c2c2e',
            'fg': '#f5f5f7',
            'fg_secondary': '#98989d',
            'accent': '#0a84ff',
            'hover': '#409cff',
            'border': '#38383a'
        }
        
        self.appliquer_theme()
    
    def appliquer_theme(self):
        """Appliquer thème"""
        self.colors = self.theme_sombre if self.mode_sombre else self.theme_clair
        self.root.configure(bg=self.colors['bg'])
    
    def creer_interface(self):
        """Interface optimisée"""
        
        # ===== TOOLBAR =====
        toolbar = tk.Frame(self.root, bg=self.colors['bg_toolbar'], height=50)
        toolbar.pack(fill='x')
        toolbar.pack_propagate(False)
        
        toolbar_content = tk.Frame(toolbar, bg=self.colors['bg_toolbar'])
        toolbar_content.pack(expand=True, pady=8)
        
        # Navigation
        nav = tk.Frame(toolbar_content, bg=self.colors['bg_toolbar'])
        nav.pack(side='left', padx=15)
        
        self.creer_btn(nav, "⏮", lambda: self.aller_page(0))
        self.creer_btn(nav, "◀", self.page_precedente)
        
        self.entry_page = tk.Entry(nav, width=5, font=('SF Pro Text', 12),
                                   bg=self.colors['bg'], fg=self.colors['fg'],
                                   relief='flat', justify='center', bd=1)
        self.entry_page.pack(side='left', padx=5)
        self.entry_page.bind('<Return>', self.aller_page_saisie)
        
        tk.Label(nav, text=f"/ {self.total_pages}",
                font=('SF Pro Text', 12),
                bg=self.colors['bg_toolbar'],
                fg=self.colors['fg_secondary']).pack(side='left', padx=3)
        
        self.creer_btn(nav, "▶", self.page_suivante)
        self.creer_btn(nav, "⏭", lambda: self.aller_page(self.total_pages-1))
        
        # Zoom
        zoom = tk.Frame(toolbar_content, bg=self.colors['bg_toolbar'])
        zoom.pack(side='left', padx=15)
        
        self.creer_btn(zoom, "−", lambda: self.zoom_delta(-0.1))
        
        self.label_zoom = tk.Label(zoom, text=f"{int(self.zoom*100)}%",
                                   font=('SF Pro Text', 12),
                                   bg=self.colors['bg_toolbar'],
                                   fg=self.colors['fg'], width=5)
        self.label_zoom.pack(side='left', padx=5)
        
        self.creer_btn(zoom, "+", lambda: self.zoom_delta(0.1))
        self.creer_btn(zoom, "⬌", self.zoom_ajuster)
        
        # Stylo
        stylo = tk.Frame(toolbar_content, bg=self.colors['bg_toolbar'])
        stylo.pack(side='left', padx=15)
        
        self.btn_stylo = self.creer_btn(stylo, "🖍️", self.toggle_stylo)
        self.creer_btn(stylo, "🎨", self.choisir_couleur)
        
        # Couleurs rapides
        colors_frame = tk.Frame(stylo, bg=self.colors['bg_toolbar'])
        colors_frame.pack(side='left', padx=5)
        
        self.creer_btn_couleur(colors_frame, "🟨", '#FFFF00')
        self.creer_btn_couleur(colors_frame, "🟥", '#FF4444')
        self.creer_btn_couleur(colors_frame, "🟩", '#44FF44')
        self.creer_btn_couleur(colors_frame, "🟦", '#4444FF')
        
        self.creer_btn(stylo, "🗑️", self.effacer_highlights)
        
        # Outils
        outils = tk.Frame(toolbar_content, bg=self.colors['bg_toolbar'])
        outils.pack(side='left', padx=15)
        
        self.creer_btn(outils, "🔍", self.toggle_recherche)
        self.creer_btn(outils, "🔲", self.toggle_miniatures)
        self.creer_btn(outils, "🌓", self.toggle_theme)
        
        # ===== RECHERCHE =====
        self.panneau_recherche = tk.Frame(self.root, bg=self.colors['bg_toolbar'], height=45)
        
        search_content = tk.Frame(self.panneau_recherche, bg=self.colors['bg_toolbar'])
        search_content.pack(expand=True, pady=8)
        
        tk.Label(search_content, text="🔍", font=('SF Pro Text', 13),
                bg=self.colors['bg_toolbar'], fg=self.colors['fg_secondary']).pack(side='left', padx=8)
        
        self.entry_recherche = tk.Entry(search_content, width=35, font=('SF Pro Text', 12),
                                        bg=self.colors['bg'], fg=self.colors['fg'],
                                        relief='flat', bd=1)
        self.entry_recherche.pack(side='left', ipady=3, ipadx=8)
        self.entry_recherche.bind('<Return>', lambda e: self.rechercher())
        self.entry_recherche.bind('<Escape>', lambda e: self.toggle_recherche())
        
        btn_search = tk.Label(search_content, text="Rechercher", font=('SF Pro Text', 11),
                             bg=self.colors['bg_toolbar'], fg=self.colors['accent'],
                             cursor='hand2', padx=10)
        btn_search.pack(side='left', padx=8)
        btn_search.bind('<Button-1>', lambda e: self.rechercher())
        
        self.label_resultats = tk.Label(search_content, text="", font=('SF Pro Text', 11),
                                        bg=self.colors['bg_toolbar'], fg=self.colors['fg_secondary'])
        self.label_resultats.pack(side='left', padx=10)
        
        # ===== ZONE PRINCIPALE =====
        main = tk.Frame(self.root, bg=self.colors['bg'])
        main.pack(fill='both', expand=True)
        
        # Miniatures
        self.sidebar = tk.Frame(main, bg=self.colors['bg_sidebar'], width=160)
        
        sidebar_canvas = tk.Canvas(self.sidebar, bg=self.colors['bg_sidebar'], highlightthickness=0)
        sidebar_canvas.pack(fill='both', expand=True, padx=5, pady=5)
        
        sidebar_scroll = ttk.Scrollbar(self.sidebar, orient='vertical', command=sidebar_canvas.yview)
        sidebar_scroll.pack(side='right', fill='y')
        sidebar_canvas.configure(yscrollcommand=sidebar_scroll.set)
        
        self.frame_miniatures = tk.Frame(sidebar_canvas, bg=self.colors['bg_sidebar'])
        sidebar_canvas.create_window((0, 0), window=self.frame_miniatures, anchor='nw')
        
        self.frame_miniatures.bind('<Configure>', 
            lambda e: sidebar_canvas.configure(scrollregion=sidebar_canvas.bbox('all')))
        
        # Canvas PDF
        canvas_container = tk.Frame(main, bg=self.colors['bg'])
        canvas_container.pack(side='left', fill='both', expand=True)
        
        self.scrollbar_y = ttk.Scrollbar(canvas_container, orient='vertical')
        self.scrollbar_y.pack(side='right', fill='y')
        
        self.scrollbar_x = ttk.Scrollbar(canvas_container, orient='horizontal')
        self.scrollbar_x.pack(side='bottom', fill='x')
        
        self.canvas = tk.Canvas(canvas_container, bg=self.colors['bg_canvas'],
                               highlightthickness=0,
                               xscrollcommand=self.scrollbar_x.set,
                               yscrollcommand=self.scrollbar_y.set)
        self.canvas.pack(fill='both', expand=True)
        
        self.scrollbar_y.configure(command=self.canvas.yview)
        self.scrollbar_x.configure(command=self.canvas.xview)
        
        # Double-clic pour zoom
        self.canvas.bind('<Double-Button-1>', lambda e: self.zoom_ajuster())
        
        # ===== BARRE STATUT =====
        status = tk.Frame(self.root, bg=self.colors['bg_toolbar'], height=26)
        status.pack(fill='x', side='bottom')
        status.pack_propagate(False)
        
        self.label_status = tk.Label(status, text=f"📄 {self.fichier_pdf.name}",
                                     font=('SF Pro Text', 10),
                                     bg=self.colors['bg_toolbar'],
                                     fg=self.colors['fg_secondary'], anchor='w')
        self.label_status.pack(side='left', padx=12, pady=3)
        
        self.label_mode = tk.Label(status, text="", font=('SF Pro Text', 10, 'bold'),
                                   bg=self.colors['bg_toolbar'],
                                   fg=self.colors['accent'], anchor='e')
        self.label_mode.pack(side='right', padx=12, pady=3)
    
    def creer_btn(self, parent, texte, commande):
        """Créer bouton"""
        btn = tk.Label(parent, text=texte, font=('SF Pro Text', 15),
                      bg=self.colors['bg_toolbar'], fg=self.colors['fg'],
                      cursor='hand2', padx=8, pady=3)
        btn.pack(side='left', padx=2)
        btn.bind('<Button-1>', lambda e: commande())
        
        def on_enter(e):
            btn.configure(bg=self.colors['border'])
        def on_leave(e):
            btn.configure(bg=self.colors['bg_toolbar'])
        
        btn.bind('<Enter>', on_enter)
        btn.bind('<Leave>', on_leave)
        return btn
    
    def creer_btn_couleur(self, parent, emoji, couleur):
        """Bouton couleur rapide"""
        btn = tk.Label(parent, text=emoji, font=('SF Pro Text', 14),
                      bg=self.colors['bg_toolbar'], cursor='hand2', padx=3)
        btn.pack(side='left')
        btn.bind('<Button-1>', lambda e: self.changer_couleur(couleur))
        return btn
    
    # ========== AFFICHAGE ==========
    
    def afficher_page(self):
        """Afficher page avec annotations"""
        if not self.doc:
            return
        
        cache_key = f"{self.page_actuelle}_{self.zoom}_{self.mode_sombre}"
        cached = self.cache_pages.get(cache_key)
        
        if cached:
            img_pil = cached
        else:
            page = self.doc[self.page_actuelle]
            mat = fitz.Matrix(self.zoom * 2, self.zoom * 2)  # DPI x2 pour qualité
            pix = page.get_pixmap(matrix=mat, alpha=False)
            img_pil = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
            self.cache_pages.set(cache_key, img_pil)
        
        # Copier pour dessiner annotations
        img_with_hl = img_pil.copy()
        draw = ImageDraw.Draw(img_with_hl, 'RGBA')
        
        # Annotations sauvegardées
        for hl in self.gestionnaire_annot.get_highlights(self.page_actuelle):
            coords = hl['coords']
            couleur = hl['couleur']
            r, g, b = int(couleur[1:3], 16), int(couleur[3:5], 16), int(couleur[5:7], 16)
            draw.rectangle(coords, fill=(r, g, b, 100))
        
        # Annotations temporaires
        for coords, couleur in self.rectangles_temp:
            r, g, b = int(couleur[1:3], 16), int(couleur[3:5], 16), int(couleur[5:7], 16)
            draw.rectangle(coords, fill=(r, g, b, 100))
        
        photo = ImageTk.PhotoImage(img_with_hl)
        
        # Afficher centré
        self.canvas.delete('all')
        canvas_w = self.canvas.winfo_width()
        canvas_h = self.canvas.winfo_height()
        img_w, img_h = photo.width(), photo.height()
        
        x = max(0, (canvas_w - img_w) // 2)
        y = max(0, (canvas_h - img_h) // 2)
        
        self.canvas.create_image(x, y, anchor='nw', image=photo, tags='page')
        self.canvas.image = photo
        self.canvas.image_offset = (x, y)
        
        self.canvas.configure(scrollregion=(0, 0, img_w + 2*x, img_h + 2*y))
        
        self.entry_page.delete(0, tk.END)
        self.entry_page.insert(0, str(self.page_actuelle + 1))
        
        self.precharger_adjacentes()
    
    def precharger_adjacentes(self):
        """Précharger pages adjacentes"""
        def worker():
            for offset in [1, -1, 2]:
                if not self.preload_active:
                    break
                page_num = self.page_actuelle + offset
                if 0 <= page_num < self.total_pages:
                    cache_key = f"{page_num}_{self.zoom}_{self.mode_sombre}"
                    if not self.cache_pages.get(cache_key):
                        try:
                            page = self.doc[page_num]
                            mat = fitz.Matrix(self.zoom * 2, self.zoom * 2)
                            pix = page.get_pixmap(matrix=mat, alpha=False)
                            img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
                            self.cache_pages.set(cache_key, img)
                        except:
                            pass
        
        threading.Thread(target=worker, daemon=True).start()
    
    def demarrer_preload(self):
        self.preload_active = True
        self.precharger_adjacentes()
    
    # ========== NAVIGATION ==========
    
    def page_precedente(self):
        if self.page_actuelle > 0:
            self.page_actuelle -= 1
            self.afficher_page()
    
    def page_suivante(self):
        if self.page_actuelle < self.total_pages - 1:
            self.page_actuelle += 1
            self.afficher_page()
    
    def aller_page(self, num):
        if 0 <= num < self.total_pages:
            self.page_actuelle = num
            self.afficher_page()
    
    def aller_page_saisie(self, event=None):
        try:
            num = int(self.entry_page.get()) - 1
            self.aller_page(num)
        except:
            pass
    
    # ========== ZOOM ==========
    
    def zoom_delta(self, delta):
        nouveau = max(0.5, min(3.0, self.zoom + delta))
        if nouveau != self.zoom:
            self.zoom = nouveau
            self.label_zoom.config(text=f"{int(self.zoom*100)}%")
            self.cache_pages.clear()
            self.afficher_page()
    
    def zoom_ajuster(self):
        if not self.doc:
            return
        page = self.doc[self.page_actuelle]
        page_w = page.rect.width
        canvas_w = self.canvas.winfo_width()
        if canvas_w > 100:
            self.zoom = (canvas_w - 40) / page_w / 2
            self.zoom = max(0.5, min(3.0, self.zoom))
            self.label_zoom.config(text=f"{int(self.zoom*100)}%")
            self.cache_pages.clear()
            self.afficher_page()
    
    # ========== SCROLL OPTIMISÉ macOS ==========
    
    def bind_scroll_macos(self):
        """Scroll optimisé pour macOS Monterey"""
        if IS_MAC:
            # Sur macOS, MouseWheel fonctionne bien
            self.canvas.bind('<MouseWheel>', self.on_scroll_mac)
        else:
            # Sur Linux/Windows
            self.canvas.bind('<Button-4>', self.on_scroll_mac)
            self.canvas.bind('<Button-5>', self.on_scroll_mac)
    
    def on_scroll_mac(self, event):
        """Scroll fluide avec changement de page"""
        # Sur macOS, event.delta est positif pour scroll haut
        if IS_MAC:
            direction = event.delta
        else:
            direction = 1 if event.num == 4 else -1
        
        if direction > 0:  # Scroll haut
            yview = self.canvas.yview()
            if yview[0] <= 0.0:
                self.page_precedente()
                self.root.after(5, lambda: self.canvas.yview_moveto(1.0))
            else:
                self.canvas.yview_scroll(-1, 'units')
        else:  # Scroll bas
            yview = self.canvas.yview()
            if yview[1] >= 1.0:
                self.page_suivante()
                self.root.after(5, lambda: self.canvas.yview_moveto(0.0))
            else:
                self.canvas.yview_scroll(1, 'units')
        
        return 'break'
    
    # ========== STYLO ==========
    
    def toggle_stylo(self):
        self.mode_stylo = not self.mode_stylo
        if self.mode_stylo:
            self.label_mode.config(text="🖍️ MODE STYLO")
            self.canvas.config(cursor='pencil')
            # Bind dessin
            self.canvas.bind('<ButtonPress-1>', self.stylo_press)
            self.canvas.bind('<B1-Motion>', self.stylo_motion)
            self.canvas.bind('<ButtonRelease-1>', self.stylo_release)
        else:
            self.label_mode.config(text="")
            self.canvas.config(cursor='arrow')
            # Unbind dessin
            self.canvas.unbind('<ButtonPress-1>')
            self.canvas.unbind('<B1-Motion>')
            self.canvas.unbind('<ButtonRelease-1>')
            # Rebind zoom
            self.canvas.bind('<Double-Button-1>', lambda e: self.zoom_ajuster())
    
    def choisir_couleur(self):
        couleur = colorchooser.askcolor(initialcolor=self.couleur_stylo, title="Couleur")
        if couleur[1]:
            self.couleur_stylo = couleur[1]
            self.label_status.config(text=f"🎨 Couleur: {self.couleur_stylo}")
    
    def changer_couleur(self, couleur):
        self.couleur_stylo = couleur
        noms = {'#FFFF00': 'Jaune', '#FF4444': 'Rouge', '#44FF44': 'Vert', '#4444FF': 'Bleu'}
        self.label_status.config(text=f"🖍️ {noms.get(couleur, couleur)}")
    
    def stylo_press(self, event):
        if not self.mode_stylo:
            return
        self.drawing = True
        x, y = self.canvas.canvasx(event.x), self.canvas.canvasy(event.y)
        if hasattr(self.canvas, 'image_offset'):
            ox, oy = self.canvas.image_offset
            x, y = x - ox, y - oy
        self.draw_start = (x, y)
    
    def stylo_motion(self, event):
        if not self.mode_stylo or not self.drawing or not self.draw_start:
            return
        x, y = self.canvas.canvasx(event.x), self.canvas.canvasy(event.y)
        if hasattr(self.canvas, 'image_offset'):
            ox, oy = self.canvas.image_offset
            x, y = x - ox, y - oy
        x1, y1 = self.draw_start
        coords = [min(x1, x), min(y1, y), max(x1, x), max(y1, y)]
        self.rectangles_temp = [(coords, self.couleur_stylo)]
        self.afficher_page()
    
    def stylo_release(self, event):
        if not self.mode_stylo or not self.drawing or not self.draw_start:
            return
        self.drawing = False
        x, y = self.canvas.canvasx(event.x), self.canvas.canvasy(event.y)
        if hasattr(self.canvas, 'image_offset'):
            ox, oy = self.canvas.image_offset
            x, y = x - ox, y - oy
        x1, y1 = self.draw_start
        coords = [min(x1, x), min(y1, y), max(x1, x), max(y1, y)]
        if abs(coords[2] - coords[0]) > 5 and abs(coords[3] - coords[1]) > 5:
            self.gestionnaire_annot.ajouter_highlight(self.page_actuelle, coords, self.couleur_stylo)
        self.rectangles_temp = []
        self.draw_start = None
        self.afficher_page()
    
    def effacer_highlights(self):
        if messagebox.askyesno("Confirmer", "Effacer tous les surlignages ?", parent=self.root):
            self.gestionnaire_annot.effacer_highlights(self.page_actuelle)
            self.afficher_page()
    
    # ========== MINIATURES ==========
    
    def toggle_miniatures(self):
        if self.sidebar.winfo_ismapped():
            self.sidebar.pack_forget()
        else:
            self.sidebar.pack(side='left', fill='y', before=self.canvas.master)
            self.generer_miniatures()
    
    def generer_miniatures(self):
        for w in self.frame_miniatures.winfo_children():
            w.destroy()
        
        def worker():
            for i in range(min(30, self.total_pages)):
                try:
                    if i not in self.cache_miniatures:
                        page = self.doc[i]
                        mat = fitz.Matrix(0.1, 0.1)
                        pix = page.get_pixmap(matrix=mat, alpha=False)
                        img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
                        photo = ImageTk.PhotoImage(img)
                        self.cache_miniatures[i] = photo
                    self.root.after(0, lambda p=i: self.afficher_miniature(p))
                except:
                    pass
        threading.Thread(target=worker, daemon=True).start()
    
    def afficher_miniature(self, page_num):
        if page_num not in self.cache_miniatures:
            return
        photo = self.cache_miniatures[page_num]
        frame = tk.Frame(self.frame_miniatures, bg=self.colors['bg_sidebar'],
                        highlightthickness=1, highlightbackground=self.colors['border'])
        frame.pack(pady=3, padx=6)
        label = tk.Label(frame, image=photo, bg=self.colors['bg_sidebar'], cursor='hand2')
        label.image = photo
        label.pack()
        label.bind('<Button-1>', lambda e, p=page_num: self.aller_page(p))
        num = tk.Label(frame, text=str(page_num + 1), font=('SF Pro Text', 8),
                      bg=self.colors['bg_sidebar'], fg=self.colors['fg_secondary'])
        num.pack()
    
    # ========== RECHERCHE ==========
    
    def toggle_recherche(self):
        if self.panneau_recherche.winfo_ismapped():
            self.panneau_recherche.pack_forget()
        else:
            self.panneau_recherche.pack(after=self.root.winfo_children()[0], fill='x')
            self.entry_recherche.focus()
    
    def rechercher(self):
        query = self.entry_recherche.get().strip()
        if not query:
            return
        self.resultats_recherche = []
        for page_num in range(self.total_pages):
            page = self.doc[page_num]
            instances = page.search_for(query)
            for inst in instances:
                self.resultats_recherche.append((page_num, inst))
        if self.resultats_recherche:
            self.index_recherche = 0
            self.aller_resultat()
            self.label_resultats.config(text=f"{len(self.resultats_recherche)} résultat(s)")
        else:
            self.label_resultats.config(text="Aucun résultat")
    
    def aller_resultat(self):
        if 0 <= self.index_recherche < len(self.resultats_recherche):
            page_num, rect = self.resultats_recherche[self.index_recherche]
            self.aller_page(page_num)
    
    # ========== THÈME ==========
    
    def toggle_theme(self):
        self.mode_sombre = not self.mode_sombre
        self.appliquer_theme()
        self.cache_pages.clear()
        self.afficher_page()
        self.root.configure(bg=self.colors['bg'])
        self.canvas.configure(bg=self.colors['bg_canvas'])
    
    # ========== RACCOURCIS ==========
    
    def bind_raccourcis(self):
        # Navigation
        self.root.bind('<Left>', lambda e: self.page_precedente())
        self.root.bind('<Right>', lambda e: self.page_suivante())
        self.root.bind('<Home>', lambda e: self.aller_page(0))
        self.root.bind('<End>', lambda e: self.aller_page(self.total_pages - 1))
        self.root.bind('<space>', lambda e: self.page_suivante())
        self.root.bind('<BackSpace>', lambda e: self.page_precedente())
        
        # Zoom
        self.root.bind('<Command-plus>', lambda e: self.zoom_delta(0.1))
        self.root.bind('<Command-minus>', lambda e: self.zoom_delta(-0.1))
        self.root.bind('<Command-0>', lambda e: self.zoom_ajuster())
        self.root.bind('<Control-plus>', lambda e: self.zoom_delta(0.1))
        self.root.bind('<Control-minus>', lambda e: self.zoom_delta(-0.1))
        self.root.bind('<Control-0>', lambda e: self.zoom_ajuster())
        
        # Recherche
        self.root.bind('<Command-f>', lambda e: self.toggle_recherche())
        self.root.bind('<Control-f>', lambda e: self.toggle_recherche())
        
        # Stylo
        self.root.bind('<Command-p>', lambda e: self.toggle_stylo())
        self.root.bind('<Control-p>', lambda e: self.toggle_stylo())
        
        # Couleurs rapides
        self.root.bind('<Command-y>', lambda e: self.changer_couleur('#FFFF00'))
        self.root.bind('<Command-r>', lambda e: self.changer_couleur('#FF4444'))
        self.root.bind('<Command-g>', lambda e: self.changer_couleur('#44FF44'))
        self.root.bind('<Command-b>', lambda e: self.changer_couleur('#4444FF'))
        
        # Thème
        self.root.bind('<Command-t>', lambda e: self.toggle_theme())
        self.root.bind('<Control-t>', lambda e: self.toggle_theme())
        
        # Miniatures
        self.root.bind('<Command-m>', lambda e: self.toggle_miniatures())
        self.root.bind('<Control-m>', lambda e: self.toggle_miniatures())
        
        # Quitter
        self.root.bind('<Escape>', lambda e: self.fermer())
        self.root.bind('<Command-w>', lambda e: self.fermer())
        self.root.bind('<Control-w>', lambda e: self.fermer())
    
    # ========== FERMETURE ==========
    
    def fermer(self):
        self.preload_active = False
        if self.doc:
            self.doc.close()
        self.root.destroy()


# ============================================================================
# FONCTION D'OUVERTURE
# ============================================================================

def ouvrir_pdf_moderne(fichier_pdf, parent=None):
    """Ouvrir PDF avec lecteur optimisé"""
    try:
        return LecteurPDFModerne(fichier_pdf, parent)
    except Exception as e:
        print(f"Erreur: {e}")
        return None

# Alias
ouvrir_pdf_rapide = ouvrir_pdf_moderne
ouvrir_pdf = ouvrir_pdf_moderne

# ============================================================================
# POINT D'ENTRÉE
# ============================================================================

if __name__ == "__main__":
    import sys
    
    print("🚀 Lecteur PDF Optimisé pour macOS Monterey 12.7.6")
    print("📱 MacBook Pro 13\" 2016 - Intel Core i7")
    print()
    
    if len(sys.argv) > 1:
        fichier = sys.argv[1]
        root = tk.Tk()
        root.withdraw()
        lecteur = ouvrir_pdf_moderne(fichier)
        if lecteur:
            lecteur.root.mainloop()
    else:
        root = tk.Tk()
        root.withdraw()
        
        fichier = filedialog.askopenfilename(
            title="Sélectionner un PDF",
            filetypes=[("PDF", "*.pdf"), ("Tous les fichiers", "*.*")]
        )
        
        if fichier:
            lecteur = ouvrir_pdf_moderne(fichier)
            if lecteur:
                lecteur.root.mainloop()
        else:
            print("❌ Aucun fichier sélectionné")